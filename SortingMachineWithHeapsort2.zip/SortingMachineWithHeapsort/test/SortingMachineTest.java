import static org.junit.Assert.assertEquals;

import java.util.Comparator;

import org.junit.Test;

import components.sortingmachine.SortingMachine;

/**
 * JUnit test fixture for {@code SortingMachine<String>}'s constructor and
 * kernel methods.
 *
 * @author Gurneer Randhawa and Amanda
 *
 */
public abstract class SortingMachineTest {

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * implementation under test and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorTest = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorTest(
            Comparator<String> order);

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * reference implementation and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorRef = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorRef(
            Comparator<String> order);

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the
     * implementation under test type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsTest = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsTest(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorTest(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the reference
     * implementation type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsRef = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsRef(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorRef(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     * Comparator<String> implementation to be used in all test cases. Compare
     * {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {

        @Override
        public int compare(String s1, String s2) {
            return s1.compareToIgnoreCase(s2);
        }

    }

    /**
     * Comparator instance to be used in all test cases.
     */
    private static final StringLT ORDER = new StringLT();

    /**
     * Sample test case 1.
     */
    @Test
    public final void testConstructor() {
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.constructorRef(ORDER);
        assertEquals(mExpected, m);
    }

    /**
     * Sample test case 2.
     */
    @Test
    public final void testAddEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green");
        m.add("green");
        assertEquals(mExpected, m);
    }

    // TODO - add test cases for add, changeToExtractionMode, removeFirst,
    // isInInsertionMode, order, and size
    //add - DONE
    //changeToExtractionMode - DONE
    //removeFirst - DONE
    //isInInsertionMode - DONE
    //order - DONE -- THERES A QUESTION IN ONE TEST CASE
    //size - DONE

    /**
     * Test for adding into a non empty with only one string intially.
     */
    @Test
    public final void testAddNotEmptyOne() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "a");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "a", "b");

        m.add("b");
        assertEquals(mExpected, m);

    }

    /**
     * Test for adding into a non empty with more than one string initially.
     */
    @Test
    public final void testAddNotEmptyMoreThanOne() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "a",
                "b", "c");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "a", "b", "c", "d");

        m.add("d");
        assertEquals(mExpected, m);
    }

    /**
     * Test for extraction mode empty.
     */
    @Test
    public final void testChangeToExtractionModeEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false);

        m.changeToExtractionMode();

        assertEquals(mExpected, m);

    }

    /**
     * Test for extraction mode not empty with one string.
     */
    @Test
    public final void testChangeToExtractionModeNonEmptyOne() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "a");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "a");

        m.changeToExtractionMode();

        assertEquals(mExpected, m);

    }

    /**
     * Test for extraction mode not empty with more than one string.
     */
    @Test
    public final void testChangeToExtractionModeNonEmptyMoreThanOne() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "a",
                "b", "c", "d");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "a", "b", "c", "d");

        m.changeToExtractionMode();

        assertEquals(mExpected, m);

    }

    /**
     * Remove first of one which results into a 0 length.
     */
    @Test
    public final void testRemoveFirstEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "a");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false);

        String removed = m.removeFirst();
        String removedExpected = "a";

        assertEquals(mExpected, m);
        assertEquals(removedExpected, removed);

    }

    /**
     * Remove first of multiple that results in a length of 1.
     */
    @Test
    public final void testRemoveFirstNotEmptyOneLeft() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "a",
                "b");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "b");

        String removed = m.removeFirst();
        String removedExpected = "a";

        assertEquals(mExpected, m);
        assertEquals(removedExpected, removed);

    }

    /**
     * Remove first of multiple that results in a length of larger than 1.
     */
    @Test
    public final void testRemoveFirstNotEmptyMoreThanOneLeft() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "a",
                "b", "c");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "b", "c");

        String removed = m.removeFirst();
        String removedExpected = "a";

        assertEquals(mExpected, m);
        assertEquals(removedExpected, removed);

    }

    /**
     * Test for insertion mode empty for true.
     */
    @Test
    public final void testIsInsertionModeTrueEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);

        assertEquals(mExpected, m);
        assertEquals(true, m.isInInsertionMode());
    }

    /**
     * Test for insertion mode empty for false.
     */
    @Test
    public final void testIsInsertionModeFalseEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false);

        assertEquals(mExpected, m);
        assertEquals(false, m.isInInsertionMode());
    }

    /**
     * Test for insertion mode non empty for true.
     */
    @Test
    public final void testIsInsertionModeTrueNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "a");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "a");

        assertEquals(mExpected, m);
        assertEquals(true, m.isInInsertionMode());
    }

    /**
     * Test for insertion mode non empty for false.
     */
    @Test
    public final void testIsInsertionModeFalseNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "a");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "a");

        assertEquals(false, m.isInInsertionMode());
    }

    /**
     * Test for order empty true.**
     */
    @Test
    public final void testOrderEmptyTrue() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);

        m.order();

        assertEquals(mExpected, m);
    }

    /**
     * Test for order empty false. ?
     */
    @Test
    public final void testOrderEmptyFalse() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false);

        m.order();

        assertEquals(mExpected, m);
    }

    /**
     * Test for order non empty true.
     */
    @Test
    public final void testOrderNonEmptyTrue() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "a",
                "c", "b");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "a", "b", "c");

        m.order();

        assertEquals(mExpected, m);
    }

    /**
     * Test for order non empty false.
     */
    @Test
    public final void testOrderNonEmptyFalse() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "a",
                "c", "b");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "a", "c", "b");

        m.order();

        assertEquals(mExpected, m);
    }

    /**
     * Test for size empty true.
     */
    @Test
    public final void testSizeEmptyTrue() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);

        int sizeOf = m.size();
        int sizeOfExpected = 0;

        assertEquals(sizeOfExpected, sizeOf);
        assertEquals(mExpected, m);
    }

    /**
     * Test for size empty false.
     */
    @Test
    public final void testSizeEmptyFalse() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false);

        int sizeOf = m.size();
        int sizeOfExpected = 0;

        assertEquals(sizeOfExpected, sizeOf);
        assertEquals(mExpected, m);
    }

    /**
     * Test for size non empty true.
     */
    @Test
    public final void testSizeNonEmptyTrue() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "a",
                "b", "c");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "a", "b", "c");

        int sizeOf = m.size();
        int sizeOfExpected = 3;

        assertEquals(sizeOfExpected, sizeOf);
        assertEquals(mExpected, m);
    }

    /**
     * Test for size non empty false.
     */
    @Test
    public final void testSizeNonEmptyFalse() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "a",
                "b", "c");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "a", "b", "c");

        int sizeOf = m.size();
        int sizeOfExpected = 3;

        assertEquals(sizeOfExpected, sizeOf);
        assertEquals(mExpected, m);
    }

}
