import java.util.Comparator;

import components.map.Map;
import components.map.Map2;
import components.queue.Queue;
import components.queue.Queue1L;
import components.queue.Queue2;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Outputs a html glossary web page that has links for each word that display
 * other web pages with the definition.
 *
 * @author Amanda Futterman
 *
 */
public final class WordCounter {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private WordCounter() {
    }

    /**
     * Compare {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {

        @Override
        public int compare(String o1, String o2) {
            return o1.toUpperCase().compareTo(o2.toUpperCase());
        }
    }

    /**
     * Removes and returns the minimum value from {@code q} according to the
     * ordering provided by the {@code compare} method from {@code order}.
     *
     * @param q
     *            the queue
     * @param order
     *            ordering by which to compare entries
     * @return the minimum value from {@code q}
     * @updates q
     * @requires <pre>
     * q /= empty_string  and
     *  [the relation computed by order.compare is a total preorder]
     * </pre>
     * @ensures <pre>
     * (q * <removeMin>) is permutation of #q  and
     *  for all x: string of character
     *      where (x is in entries (q))
     *    ([relation computed by order.compare method](removeMin, x))
     * </pre>
     */
    private static String removeMin(Queue<String> q, Comparator<String> order) {
        assert q != null : "Violation of: q is not null";
        assert order != null : "Violation of: order is not null";
        String min = "";
        Queue<String> temp = new Queue1L<>();
        min = q.dequeue();
        for (String s : q) {
            if (order.compare(s, min) < 0) {
                min = s;
                String item = q.dequeue();
                if (order.compare(item, min) < 0) {
                    q.enqueue(min);
                    min = item;
                } else {
                    q.enqueue(item);
                }
            }
        }
        for (String s : q) {
            if (!s.equals(min)) {
                temp.enqueue(s);
            }
        }
        q.transferFrom(temp);
        return min;
    }

    /**
     * Sorts {@code q} according to the ordering provided by the {@code compare}
     * method from {@code order}.
     *
     * @param q
     *            String queue containing terms
     * @param order
     *            ordering by which to sort
     * @updates q
     * @requires [the relation computed by order.compare is a total preorder]
     * @ensures q = [#q ordered by the relation computed by order.compare]
     */
    public void sort(Queue<String> q, Comparator<String> order) {
        Queue<String> ordered = new Queue1L<>();
        while (q.length() != 0) {
            ordered.enqueue(removeMin(q, order));
        }
        q.transferFrom(ordered);
    }

    /**
     * Outputs the tags for webpage.
     *
     * @param out
     *            the output stream.
     * @param m
     *            map containing words and occurances.
     * @param q
     *            queue containing words.
     * @param fileIn
     *            the input stream.
     * @updates the out.content
     * @requires out.content is open
     * @ensures out.content = #out.content * [the full HTML method tags]
     *
     */
    public static void outputHyperlinkPage(SimpleWriter out,
            Map<String, Integer> m, Queue<String> q, SimpleReader fileIn) {
        //header tags
        out.println("<html>");
        out.println("<head>");
        out.println(
                "<title> " + "Words Counted in " + fileIn.name() + "</title>");
        out.println("</head>");

        //body tags
        out.println("<body>");
        out.println("<h2>" + "Words Counted in " + fileIn.name() + "</h2>");

        //table tags
        out.println("<table border= \"1\">");
        out.println("<tr>");
        out.println("<th>Words</th>");
        out.println("<th>Counts</th>");
        out.println("</tr>");

        //loop and fill the table
        while (q.length() > 0) {
            out.println("<tr>");
            String tempK = q.dequeue();
            out.println("<td>" + tempK + "</td>");
            out.println("<td>" + m.value(tempK) + "</td>");
            out.println("<tr>");
        }

        //closing tags
        out.println("</table>");
        out.println("</body>");
        out.println("</html>");
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param pos
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code pos}
     * @requires 0 <= pos < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[pos, pos + |nextWordOrSeparator|)  and
     * if entries(text[pos, pos + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[pos, pos + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[pos, pos + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    public static String nextWordOrSeparator(Set<Character> separators, int pos,
            String text) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= pos : "Violation of: 0 <= position";
        assert pos < text.length() : "Violation of: position < |text|";
        int counter = 0;
        char c = 'a';
        String s = "";

        boolean isSep = separators.contains(text.charAt(pos));
        while (counter < text.substring(pos, text.length()).length()) {
            c = text.charAt(pos + counter);
            if (separators.contains(c) == isSep) {
                s = s + c;
            } else {
                counter = text.substring(pos, text.length()).length();
            }
            counter++;
        }
        return s;
    }

    /**
     * Updates the map and cycles through the input file.
     *
     * @param m
     *            the map holding words and occurences
     * @param fileIn
     *            the incoming text file
     * @param q
     *            queue holding words
     * @updates m
     *
     */
    public static void processFile(Map<String, Integer> m, Queue<String> q,
            SimpleReader fileIn) {
        m.clear();
        int index = 0;
        Set<Character> excludeSet = new Set1L<Character>();
        String excludeString = " \t,.-;'/\"@#$%&()";
        for (int i = 0; i < excludeString.length() - 1; i++) {
            excludeSet.add(excludeString.charAt(i));
        }

        //read all lines from input file
        while (!fileIn.atEOS()) {
            String read = fileIn.nextLine();
            index = 0;
            while (index < read.length()) {
                String c = nextWordOrSeparator(excludeSet, index, read);

                //if c is a word
                if (!excludeSet.contains(c.charAt(0))) {

                    //if not already in map
                    if (!m.hasKey(c)) {
                        m.add(c, 1);
                        q.enqueue(c); //add to queue

                        //if c is in the map already increment
                    } else {
                        int count = m.value(c);
                        count++;
                        m.replaceValue(c, count);
                    }
                }
                //look at next index
                index += c.length();
            }
        }
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        //input
        System.out.println("Enter the name of the input file:");
        SimpleReader fileIn = new SimpleReader1L("data/" + in.nextLine());

        //output
        System.out.println("Enter the name of the output file:");
        SimpleWriter fileOut = new SimpleWriter1L("data/" + in.nextLine());

        //create map and queue to hold terms and counts
        Map<String, Integer> m = new Map2<>();
        Queue<String> q = new Queue2<>();
        Comparator<String> cs = new StringLT();

        //fills map by reading through incoming file
        processFile(m, q, fileIn);

        //sort words
        q.sort(cs);

        //create hyperlink page
        outputHyperlinkPage(fileOut, m, q, fileIn);

        //Closing statements
        fileOut.close();
        in.close();
        fileIn.close();
        out.close();
    }
}
