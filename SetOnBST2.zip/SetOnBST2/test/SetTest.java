import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.set.Set;

/**
 *
 * JUnit test fixture for {@code Set<String>}'s constructor and kernel methods.
 *
 *
 *
 * @author Gurneer Randhawa and Amanda Futterman
 *
 *
 *
 */

public abstract class SetTest {

    /**
     *
     * Invokes the appropriate {@code Set} constructor for the implementation
     *
     * under test and returns the result.
     *
     *
     *
     * @return the new set
     *
     * @ensures constructorTest = {}
     *
     */

    protected abstract Set<String> constructorTest();

    /**
     *
     * Invokes the appropriate {@code Set} constructor for the reference
     *
     * implementation and returns the result.
     *
     *
     *
     * @return the new set
     *
     * @ensures constructorRef = {}
     *
     */

    protected abstract Set<String> constructorRef();

    /**
     *
     * Creates and returns a {@code Set<String>} of the implementation under
     *
     * test type with the given entries.
     *
     *
     *
     * @param args
     *
     *            the entries for the set
     *
     * @return the constructed set
     *
     * @requires [every entry in args is unique]
     *
     * @ensures createFromArgsTest = [entries in args]
     *
     */
    private Set<String> createFromArgsTest(String... args) {
        Set<String> set = this.constructorTest();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     *
     * Creates and returns a {@code Set<String>} of the reference implementation
     *
     * type with the given entries.
     *
     *
     *
     * @param args
     *
     *            the entries for the set
     *
     * @return the constructed set
     *
     * @requires [every entry in args is unique]
     *
     * @ensures createFromArgsRef = [entries in args]
     *
     */
    private Set<String> createFromArgsRef(String... args) {
        Set<String> set = this.constructorRef();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     *
     * Test for the constructor.
     *
     */
    @Test
    public final void constructorTest1() {
        Set<String> q = this.constructorTest();
        Set<String> qExpected = this.constructorRef();
        assertEquals(qExpected, q);
    }

    /**
     *
     * Test for adding to a empty set.
     *
     */
    @Test
    public final void addEmptyTest() {
        Set<String> orig = this.createFromArgsTest();
        Set<String> origExpected = this.createFromArgsRef("hi");
        orig.add("hi");
        assertEquals(orig, origExpected);
    }

    /**
     *
     * Test for adding to a non empty set.
     *
     */
    @Test
    public final void addNonEmptyTest() {
        Set<String> orig = this.createFromArgsTest("hi", "how", "are");
        Set<String> origExpected = this.createFromArgsRef("hi", "how", "are",
                "you");
        orig.add("you");
        assertEquals(orig, origExpected);
    }

    /**
     *
     * Test for removing one resulting in an empty Set.
     *
     */
    @Test
    public void removeOneToEmptyTest() {
        Set<String> s = this.createFromArgsTest("a");
        Set<String> e = this.createFromArgsRef();
        String temp = s.remove("a");
        assertEquals(temp, "a");
        assertEquals(s, e);
    }

    /**
     *
     * Test for removing one with other things left in the set.
     *
     */
    @Test
    public void removeOne() {
        Set<String> s = this.createFromArgsTest("a", "b");
        Set<String> e = this.createFromArgsRef("a");
        String temp = s.remove("b");
        assertEquals(temp, "b");
        assertEquals(s, e);
    }

    /**
     *
     * Test for removeAny with one thing left over in the Set.
     *
     */
    @Test
    public void removeAnyTest1() {
        Set<String> s = this.createFromArgsTest("a", "b");
        Set<String> e = this.createFromArgsRef("a", "b");
        String removed = s.removeAny();
        assertTrue(e.contains(removed));
        String removedExpected = e.remove(removed);
        assertEquals(e, s);
        assertEquals(removedExpected, removed);
    }

    /**
     *
     * Test for contains if true.
     *
     */
    @Test
    public void containsTrueTest() {
        Set<String> s = this.createFromArgsTest("a", "b");
        Set<String> e = this.createFromArgsRef("a", "b");
        boolean temp = s.contains("b");
        assertEquals(e, s);
        assertEquals(temp, true);
    }

    /**
     *
     * Test for contains if false.
     *
     */
    @Test
    public void containsFalseTest() {
        Set<String> s = this.createFromArgsTest("a", "b");
        Set<String> e = this.createFromArgsRef("a", "b");
        boolean temp = s.contains("c");
        assertEquals(e, s);
        assertEquals(temp, false);
    }

    /**
     *
     * Test for contains with an empty set.
     *
     */
    @Test
    public void containsEmptyTest() {
        Set<String> s = this.createFromArgsTest();
        Set<String> e = this.createFromArgsRef();
        boolean temp = s.contains("a");
        assertEquals(e, s);
        assertEquals(temp, false);
    }

    /**
     *
     * Test for size of more than 1.
     *
     */
    @Test
    public void sizeMultipleTest() {
        Set<String> s = this.createFromArgsTest("a", "b");
        Set<String> e = this.createFromArgsRef("a", "b");
        int temp = s.size();
        assertEquals(e, s);
        assertEquals(temp, 2);
    }

    /**
     *
     * Test for size of zero.
     *
     */
    @Test
    public void sizeEmptyTest() {
        Set<String> s = this.createFromArgsTest();
        Set<String> e = this.createFromArgsRef();
        int temp = s.size();
        assertEquals(e, s);
        assertEquals(temp, 0);
    }

    /**
     *
     * Test for size of one.
     *
     */
    @Test
    public void sizeOneTest() {
        Set<String> s = this.createFromArgsTest("a");
        Set<String> e = this.createFromArgsRef("a");
        int temp = s.size();
        assertEquals(e, s);
        assertEquals(temp, 1);
    }

}
